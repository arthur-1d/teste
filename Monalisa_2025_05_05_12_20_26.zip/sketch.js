function setup() {
  createCanvas(400,400);
}
let olhoX
let olhoY
function draw() {
  background("black");
  fill("yellow")
  circle(200, 200, 300);
   fill("blue")
  circle(150, 150, 60);
  circle(250, 150, 60);
  line(150,270,250,235)
  fill("green")
  triangle(200,180,170,220,220,220)
  line(250,269,150,239)
  triangle(131,108,170,110,151,89)
  triangle(223,109,267,110,241,90)
  fill("white")
  //circle(150,150,10)
  //circle(250,150,10)
  
  olhoX = map(mouseX,0,400,130,170);
  olhoY = map(mouseY,0,400,130,170);
  
  circle(olhoX,olhoY,10);
  circle(olhoX+100,olhoY,10);
  if(mouseIsPressed){
     console.log(mouseX,mouseY);
     }
  
}